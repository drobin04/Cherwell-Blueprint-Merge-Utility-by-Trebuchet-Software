﻿Public Class SettingsList
	Public Property SettingsList As List(Of JSONConfigFileSetting)

End Class