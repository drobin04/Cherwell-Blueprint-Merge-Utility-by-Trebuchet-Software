﻿Imports System.IO
Imports System.Web.Script.Serialization

Public Class ConfigurationFile

	Public Property FilePath As String
	Public Property SettingsCount As Integer = 0

	Public Property SettingsList As New List(Of JSONConfigFileSetting)

	'Instructions - 
	'Send file path to New constructor
	'Use Add-setting method to add a key-value pair for a setting
	'Use ExportSettingsToFile method to save.

	Public Sub New(Path As String)
		FilePath = Path



	End Sub


	Public Sub AddSetting(Name As String, Value As String)
		Dim NewSetting As New JSONConfigFileSetting(Name, Value.Replace("\", "\\"))
		SettingsList.Add(NewSetting)

	End Sub

	Public Sub ExportSettingsToFile()
		Dim File As New IO.StreamWriter(FilePath)
		File.Write("{")
		File.Write("""SettingsList"": [") 'Write settings as part of an array to make deserializing a list easier

		For Each Setting As JSONConfigFileSetting In SettingsList

			If SettingsCount >= 1 Then
				File.Write(",")
			End If
			File.Write("{")
			File.Write(Setting.GetSettingText)
			File.Write("}")
			SettingsCount += 1
		Next
		File.Write("]}") 'End JSON Array

		File.Close()

	End Sub

	Public Sub ReadSettingsFromFile()


		Dim File As StreamReader
		File = IO.File.OpenText(FilePath)

		Dim FileContents As String = File.ReadToEnd
		Dim jss As New JavaScriptSerializer()
		Dim settings As New SettingsList
		settings = jss.Deserialize(Of SettingsList)(FileContents)
		SettingsList = settings.SettingsList


	End Sub

	Public Function GetSettingValueByName(SettingName As String) As String

		For Each Setting As JSONConfigFileSetting In SettingsList
			If Setting.SettingName = SettingName Then
				Return Setting.SettingValue

			Else
				'Return ""
			End If


		Next

		Return ""

	End Function

End Class
